#include <iostream>
#include <vector>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <unistd.h>
#include "objParser.hpp"
#include "main.hpp"

#define WIDTH 1280
#define HEIGHT 720
#define FOV 100

void render(Object3D object, SDL_Renderer *renderer) {
    for (int face = 0; face < object.faces.size(); face++) {
        SDL_SetRenderDrawColor(renderer, object.faces[face].color[0], object.faces[face].color[1], object.faces[face].color[2], 255);
        SDL_RenderDrawLines(renderer, object.faces[face].vertexesProjected, 3);
    }
}

Object3D project(Object3D object, int fov) {
    Object3D objectProjected = object;
    int Fov = fov;

    for (int face = 0; face < object.faces.size(); face++) {
        for (int vertex = 0; vertex < 3; vertex++) {
            objectProjected.faces[face].vertexesProjected[vertex].x = (objectProjected.faces[face].vertexes[vertex].x * Fov/ objectProjected.faces[face].vertexes[vertex].z)+ WIDTH / 2;
            objectProjected.faces[face].vertexesProjected[vertex].y = (objectProjected.faces[face].vertexes[vertex].y * Fov / objectProjected.faces[face].vertexes[vertex].z) + HEIGHT / 2;

        }
    }

    return objectProjected;
}

Object3D transform(Object3D object, Vector3 cameraPos) {
    Object3D objectTransformed;

    for (int face = 0; face < object.faces.size(); face++) {
        Face3D tempFace;
        for (int vertex = 0; vertex < 3; vertex++) {
            Vector3 v = {object.faces[face].vertexes[vertex].x, object.faces[face].vertexes[vertex].y, object.faces[face].vertexes[vertex].z};
            v.x -= cameraPos.x;
            v.y -= cameraPos.y;
            v.z -= cameraPos.z;
            tempFace.vertexes[vertex] = v;
            tempFace.color[0] = object.faces[face].color[0];
            tempFace.color[1] = object.faces[face].color[1];
            tempFace.color[2] = object.faces[face].color[2];
        }
        objectTransformed.faces.push_back(tempFace);
    }

    return objectTransformed;
}

Object3D rotate(Object3D object, Vector3 cameraRot) {
    Object3D objectRotated = object;

    float rotMatrixY[3][3] = {{cos(cameraRot.y), 0, sin(cameraRot.y)},
                              {0, 1, 0},
                              {-sin(cameraRot.y), 0, cos(cameraRot.y)}};

    for (int face = 0; face < object.faces.size(); face++) {
        for (int vertex = 0; vertex < 3; vertex++) {
            float v[] = {object.faces[face].vertexes[vertex].x, object.faces[face].vertexes[vertex].y, object.faces[face].vertexes[vertex].z};
            float rotYV[3];
            rotYV[0] = (rotMatrixY[0][0] * v[0]) + (rotMatrixY[0][1] * v[1]) + (rotMatrixY[0][2] * v[2]);
            rotYV[1] = (rotMatrixY[1][0] * v[0]) + (rotMatrixY[1][1] * v[1]) + (rotMatrixY[1][2] * v[2]);
            rotYV[2] = (rotMatrixY[2][0] * v[0]) + (rotMatrixY[2][1] * v[1]) + (rotMatrixY[2][2] * v[2]);

            objectRotated.faces[face].vertexes[vertex].x = rotYV[0];
            objectRotated.faces[face].vertexes[vertex].y = rotYV[1];
            objectRotated.faces[face].vertexes[vertex].z = rotYV[2];
        }
    }

    return objectRotated;
}

int main() {
    SDL_Window* window = NULL;
    SDL_Renderer* renderer = NULL;

    int SDL_FLAGS = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;

    window = SDL_CreateWindow("3D-Renderer", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WIDTH, HEIGHT, SDL_WINDOW_SHOWN | SDL_SWSURFACE);
    renderer = SDL_CreateRenderer(window, -1, SDL_FLAGS);

    // Create Object
    std::string path = "lander_A.obj";
    Object3D object = parse(path);

    // Camera
    Vector3 cameraPos = {0, 0, 10};
    Vector3 cameraRot = {0, 0, 0};

    // MAIN LOOP
    bool QUIT = false;
    while (!QUIT) {
        // Handle Events
        SDL_Event event;
        while (SDL_PollEvent(&event) != 0){
            switch (event.type) {
                case SDL_QUIT:
                    QUIT = true;  
                    break;

                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym) {
                        case SDLK_a:
                            cameraPos.x += 0.1*cos(cameraRot.y);
                            cameraPos.z += 0.1*sin(cameraRot.y);
                            break;
                        case SDLK_d:
                            cameraPos.x -= 0.1*cos(cameraRot.y);
                            cameraPos.z -= 0.1*sin(cameraRot.y);
                            break;
                        case SDLK_w:
                            cameraPos.x += 0.1*sin(cameraRot.y);
                            cameraPos.z -= 0.1*cos(cameraRot.y);
                            break;
                        case SDLK_s:
                            cameraPos.x -= 0.1*sin(cameraRot.y);
                            cameraPos.z += 0.1*cos(cameraRot.y);
                            break;
                        case SDLK_SPACE:
                            cameraPos.y += 0.1;
                            break;
                        case SDLK_LSHIFT:
                            cameraPos.y -= 0.1;
                            break;
                        case SDLK_RIGHT:
                            cameraRot.y -= 0.05236;
                            break;
                        case SDLK_LEFT:
                            cameraRot.y += 0.05236;
                            break;
                    }
                    break;

                default:
                    break;
            }
        }
        Object3D object3D = object;
        // perform Object3D transformations
        object3D = transform(object3D, cameraPos);
        object3D = rotate(object3D, cameraRot);
        object3D = project(object3D, FOV);

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);
        render(object3D, renderer);
        SDL_RenderPresent(renderer);

        // sleep ~60fps
        usleep(16666);
    }

    // QUIT
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    window = NULL;
    renderer = NULL;
    SDL_Quit();

    return 0;
}