#pragma once
#include <string>
#include "main.hpp"

Object3D parse(std::string path);